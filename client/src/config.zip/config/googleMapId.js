const googleMapID = "AIzaSyCjp5Sxe-c5mUn1GtfLqEatR0mt7cXYdIM";
export default googleMapID;