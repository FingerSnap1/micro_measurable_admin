const allowedEmails = ["pohangavengers@gmail.com", "22000539@handong.ac.kr"];
export default allowedEmails;