const allowedEmails = ["pohangavengers@gmail.com", 
                        "22000539@handong.ac.kr", "21700528@handong.ac.kr", 
                        "gusehx7191@handong.ac.kr", "21900577@handong.ac.kr",
                        "21900579@handong.ac.kr", "dmsvk01@handong.ac.kr", 
                        "hsh21900783@handong.ac.kr", "22000141@handong.ac.kr"];
export default allowedEmails;