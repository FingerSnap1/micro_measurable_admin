const { initializeApp } = require("firebase-admin/app");
const admin = require("firebase-admin");
const { getFirestore } = require("firebase-admin/firestore");

// Firebase Admin SDK 설정 파일 다운로드 및 서비스 계정 키 경로 설정
const serviceAccount = require("./capstone-c6d9e-firebase-adminsdk-3u13k-8db20b4eb6.json");

// Firebase Admin SDK 초기화
const firebaseAdminApp = initializeApp({
  credential: admin.credential.cert(serviceAccount),
  // databaseURL: "https://capstone-c6d9e-default-rtdb.firebaseio.com", // Firebase 프로젝트의 실제 URL로 대체
});

const db = getFirestore(firebaseAdminApp);

module.exports = db;

